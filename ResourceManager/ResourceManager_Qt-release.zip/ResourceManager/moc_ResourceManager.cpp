/****************************************************************************
** Meta object code from reading C++ file 'ResourceManager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ResourceManager/ResourceManager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ResourceManager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ResourceManager_t {
    QByteArrayData data[14];
    char stringdata0[166];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ResourceManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ResourceManager_t qt_meta_stringdata_ResourceManager = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ResourceManager"
QT_MOC_LITERAL(1, 16, 22), // "readFromQStringContext"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 7), // "context"
QT_MOC_LITERAL(4, 48, 9), // "showGraph"
QT_MOC_LITERAL(5, 58, 6), // "insert"
QT_MOC_LITERAL(6, 65, 15), // "derivative_name"
QT_MOC_LITERAL(7, 81, 13), // "material_name"
QT_MOC_LITERAL(8, 95, 10), // "deleteNode"
QT_MOC_LITERAL(9, 106, 4), // "name"
QT_MOC_LITERAL(10, 111, 15), // "displayNodelist"
QT_MOC_LITERAL(11, 127, 9), // "saveGraph"
QT_MOC_LITERAL(12, 137, 4), // "path"
QT_MOC_LITERAL(13, 142, 23) // "getTextDataFromNodeList"

    },
    "ResourceManager\0readFromQStringContext\0"
    "\0context\0showGraph\0insert\0derivative_name\0"
    "material_name\0deleteNode\0name\0"
    "displayNodelist\0saveGraph\0path\0"
    "getTextDataFromNodeList"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ResourceManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // methods: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x02 /* Public */,
       4,    0,   52,    2, 0x02 /* Public */,
       5,    2,   53,    2, 0x02 /* Public */,
       8,    1,   58,    2, 0x02 /* Public */,
      10,    0,   61,    2, 0x02 /* Public */,
      11,    1,   62,    2, 0x02 /* Public */,
      13,    0,   65,    2, 0x02 /* Public */,

 // methods: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    6,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::QVariantList,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::QString,

       0        // eod
};

void ResourceManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ResourceManager *_t = static_cast<ResourceManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->readFromQStringContext((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: { QString _r = _t->showGraph();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 2: _t->insert((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 3: _t->deleteNode((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: { QVariantList _r = _t->displayNodelist();
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->saveGraph((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: { QString _r = _t->getTextDataFromNodeList();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject ResourceManager::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ResourceManager.data,
      qt_meta_data_ResourceManager,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ResourceManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ResourceManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ResourceManager.stringdata0))
        return static_cast<void*>(const_cast< ResourceManager*>(this));
    return QObject::qt_metacast(_clname);
}

int ResourceManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
